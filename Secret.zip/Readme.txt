===========================
This bat file will give you a secret storage space of how much stoage depen of  drive leater storage 
============================
File By changuoxin333
Password = [changuoxin333]
=============================
Copyright changuoxin333 
=============================
Copyright Disclaimer
File made changuoxin333
If found copying file by changuoxin333
We will REPORT to GITHUB
==============================
If want to change drive leater 
ONLY CHANGE frist 2 C[Drive Leater]
==============================
Default [Drive Leather] is C drive
==================================